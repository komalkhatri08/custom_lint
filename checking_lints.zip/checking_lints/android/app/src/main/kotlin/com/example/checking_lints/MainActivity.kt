package com.example.checking_lints

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}

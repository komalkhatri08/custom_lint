class MyService {}

class MyService1 {}
